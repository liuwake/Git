---
name: "\U0001F680Feature or Enhancement"
about: Suggest an Idea or Enhancement
---

### Description

<!--- Provide a detailed description of the change or addition you are proposing -->

### Why

<!--- Why is this change important to you? How would you use it? -->

<!--- How can it benefit other users? -->

### Possible Implementation & Open Questions

<!--- Not obligatory, but suggest an idea for implementing addition or change -->

<!--- What still needs to be discussed -->

### Is this something you're interested in working on?

<!--- Yes or no -->
- [ ] YES
- [ ] NO
