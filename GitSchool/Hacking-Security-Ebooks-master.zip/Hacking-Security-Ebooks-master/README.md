# Hacking-Security-Ebooks
Top 100 Hacking &amp; Security E-Books (Free Download) - Powered by <a href="https://www.yeahhub.com/biggest-hacking-security-ebooks-collection-free-download/">Yeahhub.com</a>.

<table width="100%" class="table">
<tr>
<th>S.No</th>
<th>E-Book (PDF Link)</th>
<th>Total Pages</th>
</tr>
<tr><td>1.</td><td><a target="_blank" href="https://mega.nz/#!rOowCA6L!rLmfn-cda99y9VF9NaV53xQEzIY_wHVtyRodLU-qKyg">Advanced Penetration Testing</a></td><td>269 Pages</td></tr>
<tr><td>2.</td><td><a target="_blank" href="https://mega.nz/#!veogDIDB!F7jKWnuYmiA31vI7AcUbOJ_8bpttxz4wDIDEjxzJBDc">The Basics of Web Hacking</a></td><td>179 Pages</td></tr>
<tr><td>3.</td><td><a target="_blank" href="https://mega.nz/#!yHpgQKrL!ctQd0e-yzb1QXoYk01yPTA9jl78TbNaZI4GoLdg6PSo">The Basics of Hacking and Penetration Testing</a></td><td>178 Pages</td></tr>
<tr><td>4.</td><td><a target="_blank" href="https://mega.nz/#!zCoCmChR!yR6BzKz4sva2qAzRMCju1jpHphgwe12ssZLknBNk4yc">The Art of Deception by Kevin Mitnick</a></td><td>577 Pages</td></tr>
<tr><td>5.</td><td><a target="_blank" href="https://mega.nz/#!Kf4CXSYQ!ZovQRMu6VMwkdLqOFhuUi4wCj7Pq0PJgiHZiItUt0DY">SQL Injection Attacks and Defense</a></td><td>761 Pages</td></tr>
<tr><td>6.</td><td><a target="_blank" href="https://mega.nz/#!Heg0jCQZ!Y6ZftkyGJc8Rw2WI63v213iIl_SMEtY1qBsb7p2nQjs">Metasploit - The Penetration Tester's Guide</a></td><td>332 Pages</td></tr>
<tr><td>7.</td><td><a target="_blank" href="https://mega.nz/#!XKgAEIqJ!jQ0ohALFI2fKrO6S5JzRjOZn6YmAMqKgkCPQLM0Peew">Ethical Hacking and Penetration Testing Guide</a></td><td>523 Pages</td></tr>
<tr><td>8.</td><td><a target="_blank" href="https://mega.nz/#!jSpChSpb!UGry-SnTLB3s4qMfh29s6jDromDGQc8I_fkWIqAY6rc">Network Attacks and Exploitation - A Framework</a></td><td>219 Pages</td></tr>
<tr><td>9.</td><td><a target="_blank" href="https://mega.nz/#!jCp0QCpb!QBzvaWSfkmBg3k1sOx8LAGw-t6Cb-RaHC3tQ39hgddY">Python Web Penetration Testing Cookbook</a></td><td>224 Pages</td></tr>
<tr><td>10.</td><td><a target="_blank" href="https://mega.nz/#!fXwylIQA!ZPFmeFnccvR4ltf_2lwTdi8PqHIArRx_bkqRP9wwq4k">Wireshark for Security Professionals</a></td><td>391 Pages</td></tr>
<tr><td>11.</td><td><a target="_blank" href="https://mega.nz/#!iHhGWKhY!-H1nMNg4LjXrDc_hIpyG0IXJ_N2GGdvjqcpaT_mkQ70">Mastering Modern Web Penetration Testing</a></td><td>298 Pages</td></tr>
<tr><td>12.</td><td><a target="_blank" href="https://mega.nz/#!Ka4yASIL!8yNyiuSHVQ3gOib4rKJYtwsCwSfqAfoFj2lQtwUyI8o">The Shellcoder's Handbook</a></td><td>745 Pages</td></tr>
<tr><td>13.</td><td><a target="_blank" href="https://mega.nz/#!6e4UiY5A!3r2oy2AsGXR3P7f8K7xvL2kEVjR6ccze83cAmz9VIBc">The Little Black Book of Computer Viruses</a></td><td>183 Pages</td></tr>
<tr><td>14.</td><td><a target="_blank" href="https://mega.nz/#!faoQUSYa!qAda14pWUjd5u4wjOYmzCI52UMa1rUFulh7V0kBGZk8">XSS Attacks - Cross Site Scripting Exploits and Defense</a></td><td>482 Pages</td></tr>
<tr><td>15.</td><td><a target="_blank" href="https://mega.nz/#!DWowAYRA!hVGYbGKJCcbUh83yztODz-8aMZZbJMWPoCdmr5Z4C9w">The Web Application Hacker's Handbook</a></td><td>771 Pages</td></tr>
<tr><td>16.</td><td><a target="_blank" href="https://mega.nz/#!aX4CEAgS!tpFivx91Ips2rR3UnVdtlgvx1oOmi-qEtCu29DlO9uQ">Ethical Hacking and Countermeasures</a></td><td>239 Pages</td></tr>
<tr><td>17.</td><td><a target="_blank" href="https://mega.nz/#!jSwgGCyY!MB5a5s9wpaWEEGnhi5j_73kMtPIQx0rEuQXv5_Y_gd4">Reversing - Secrets of Reverse Engineering</a></td><td>619 Pages</td></tr>
<tr><td>18.</td><td><a target="_blank" href="https://mega.nz/#!CGgCiKqC!PXzqsNN2PPc-PUVyAwbfknTHEA-QBvjwvpjjQgZnYMo">Network Security Bible</a></td><td>697 Pages</td></tr>
<tr><td>19.</td><td><a target="_blank" href="https://mega.nz/#!3KhWgIzQ!QQ8O9k6lp7vmYWzrbxbs8ItSVbYpSluYfktCxWURZGs">Hacking Web Applications - Hacking Exposed</a></td><td>416 Pages</td></tr>
<tr><td>20.</td><td><a target="_blank" href="https://mega.nz/#!6exQSaLK!ur1W05ChW7_ipTYtEK6QKpIlyoqLyS82RGsEUEzFQDQ">Hacking for Dummies</a></td><td>387 Pages</td></tr>
<tr><td>21.</td><td><a target="_blank" href="https://mega.nz/#!Le5kmAAT!TvvIUOn5TQ4HsS4qrTAX6dOD0JG4tZ9FtLj6bEFGg2M">Hacking Wireless Network for Dummies</a></td><td>387 Pages</td></tr>
<tr><td>22.</td><td><a target="_blank" href="https://mega.nz/#!SLwCwKSD!b018YKF4UZ2xRh0mqouRm6pssXd0lbWRuwCoPepxW2Q">Ninja Hacking - Unconventional Penetration Testing Tacting and Techniques</a></td><td>314 pages</td></tr>
<tr><td>23.</td><td><a target="_blank" href="https://mega.nz/#!rfxERC5B!GWFniwOY738v8URo3HsnQwVV5h957-Ppx7FxMwYmJCI">Professional Penetration Testing</a></td><td>525 Pages</td></tr>
<tr><td>24.</td><td><a target="_blank" href="https://mega.nz/#!XLo2hYAK!8bmNXXPvSgIotZTsPbGaR-dSj9MfyOoNmm7iZ2me798">Gray Hat Hacking - The Ethical Hacker's Handbook</a></td><td>577 Pages</td></tr>
<tr><td>25.</td><td><a target="_blank" href="https://mega.nz/#!PPpwGKTT!pkJBqjgeN_BJWe8PRveaA4nwRICK7WQ80BUowDSVfXI">Hack Attacks Testing</a></td><td>561 Pages</td></tr>
<tr><td>26.</td><td><a target="_blank" href="https://mega.nz/#!Sfx2WCBC!oh0fxNYfOqiyCNoeyqayetg_e2G3B8ZF7M3lr3NMCgU">Basic Security Testing with Kali Linux</a></td><td>242 Pages</td></tr>
<tr><td>27.</td><td><a target="_blank" href="https://mega.nz/#!iT5AVK4T!-lJxNzy1PzA6lD2pILs_f11KgvI3seA_T9z0MmAKmGU">Mastering Kali Linux for Advanced Penetration Testing</a></td><td>356 Pages</td></tr>
<tr><td>28.</td><td><a target="_blank" href="https://mega.nz/#!be4CUI5S!t5gnnoTcix052g50CZeOZhs-jzJsGiPikSTZWqAFvFA">Kali Linux CTF Blueprints</a></td><td>190 Pages</td></tr>
<tr><td>29.</td><td><a target="_blank" href="https://mega.nz/#!uPpwASaK!SVx2QJw9zOBPIFcfwFqU7jZpGSAe8NEs0um1cqn1m5E">Kali Linux Cookbook</a></td><td>261 Pages</td></tr>
<tr><td>30.</td><td><a target="_blank" href="https://mega.nz/#!yGg21Q5I!QpCaOuvULnshcJV-Kgv09y_R-etiGo4Y7769JLIARmY">Kali Linux - Assuring Security by Penetration Testing</a></td><td>454 Pages</td></tr>
<tr><td>31.</td><td><a target="_blank" href="https://mega.nz/#!mC4QBApT!vZXeBRcG7poaDNMaNd9XXe7FYWAO8MIk4DYmglq1tBQ">Information Security  Management Handbook</a></td><td>3206 Pages</td></tr>
<tr><td>32.</td><td><a target="_blank" href="https://mega.nz/#!vfwgjQRC!wjKpxiT-qi9r5W8px3-aDqiglZMr1fyh3ThkwPPyrRQ">Computer and Information Security Handbook</a></td><td>877 Pages</td></tr>
<tr><td>33.</td><td><a target="_blank" href="https://mega.nz/#!aHgkjC6A!Z0ox5K8qeLeobE6VoBeXsrO5mxu68HeaczcCFRg5hC8">CISSP - Certified Information Systems Security Professional</a></td><td>804 Pages</td></tr>
<tr><td>34.</td><td><a target="_blank" href="https://mega.nz/#!KTgklaza!nnLb6e1SWgEL6D3kqdY2FLmHhK8wuxHUyJM-ghiC4JI">Computer Security and Cryptography</a></td><td>542 Pages</td></tr>
<tr><td>35.</td><td><a target="_blank" href="https://mega.nz/#!3Goi3IAQ!BlJ7rynz9UHI74hTmlJzroUgbOiy1O-cpFun5qeNjVg">Python for Kids</a></td><td>348 Pages</td></tr>
<tr><td>36.</td><td><a target="_blank" href="https://mega.nz/#!Peh0mC7a!vvwYa_Z95mtaWhWSPDBot7fINfoQ8cpnH4qm9xus1TY">End to End Network Security - Defense-in-Depth</a></td><td>469 Pages</td></tr>
<tr><td>37.</td><td><a target="_blank" href="https://mega.nz/#!fX4iEITT!Qx7oHuIWzeUjBMxRKMFo-lUkiKnliQOJUAjoFJfSLDM">A Guide to Computer Network Security</a></td><td>483 Pages</td></tr>
<tr><td>38.</td><td><a target="_blank" href="https://mega.nz/#!POhgFI7b!R16cOg64vgZxs02bTFD7dYSXRgZDLcog2lcb5CJ33k8">Essential Computer Security</a></td><td>321 Pages</td></tr>
<tr><td>39.</td><td><a target="_blank" href="https://mega.nz/#!OagEgKIR!6HKrc6AA3oMLl5GB5CnwmXtbH9cVkqqU-4PBdJZcNaE">Security in Wireless Mesh Networks</a></td><td>548 Pages</td></tr>
<tr><td>40.</td><td><a target="_blank" href="https://mega.nz/#!ebwQWSSK!Lfw_qx1ljqzXmJnnl0x68v_4iR3B2AIIOr-LaPRzLm0">Hacking Windows XP (OLD)</a></td><td>379 Pages</td></tr>
<tr><td>41.</td><td><a target="_blank" href="https://mega.nz/#!CCwkhCTK!nrX0SEvIU_LJB8UNQwn7xCmnMAoELGGS69lVRehN6T4">Hacking Exposed - Windows Security, Secrets and Solutions</a></td><td>482 Pages</td></tr>
<tr><td>42.</td><td><a target="_blank" href="https://mega.nz/#!vH5AHawI!o3ZyT0v2NK1PjxeGtynIw8v3gS7g_0Yk4AN3ofXIWdc">Hacking Exposed - Network Security, Secrets and Solutions</a></td><td>736 Pages</td></tr>
<tr><td>43.</td><td><a target="_blank" href="https://mega.nz/#!jPxkDCAS!YmsoJD1cT0hpl3d3No7HnAFIlrdYe7qDpDP4UkgQ25U">Information Security - Principles and Pratice</a></td><td>413 Pages</td></tr>
<tr><td>44.</td><td><a target="_blank" href="https://mega.nz/#!nTwkTa6A!nu3Tm3jGmNunHmXmo4JfC42DlqFMppgvPTlD0ej_rkA">Nessus, Snort and Ethereal Power Tools</a></td><td>472 Pages</td></tr>
<tr><td>45.</td><td><a target="_blank" href="https://mega.nz/#!XDwESQKA!xTwUl8VcecQrj7_R_HatjES5oeyVT-v0TbQlBEkHrk8">Active Defense - A Comprehensive Guide to Network Security</a></td><td>374 Pages</td></tr>
<tr><td>46.</td><td><a target="_blank" href="https://mega.nz/#!yHh23SqI!X3pfvBocXuVnPdbX12X9vJMy3fFPf3JdRJP9fDDE6U0">Information Security Fundamentals</a></td><td>262 Pages</td></tr>
<tr><td>47.</td><td><a target="_blank" href="https://mega.nz/#!Le4GgCaT!NdoHXh5mnLFVk6e1_qtXiofBOId35IdhgZw-84f856E">Wireless Network Security</a></td><td>422 Pages</td></tr>
<tr><td>48.</td><td><a target="_blank" href="https://mega.nz/#!ve5C2IrB!C26PIIc3-vbTdX0LkULGKce4Pfn8Z7jlVxKYQJIYdSk">Red Hat Linux Security and Optimization</a></td><td>721 Pages</td></tr>
<tr><td>49.</td><td><a target="_blank" href="https://mega.nz/#!Ce4iAYAB!ZCrYRdy5fXF6RwrDu8XsQoE0xXGkH88iTNcTg9Zlv6U">Windows Forensics Analysis</a></td><td>386 Pages</td></tr>
<tr><td>50.</td><td><a target="_blank" href="https://mega.nz/#!XOgE2CqC!9jGzTWQUVkyIHRKaSLH5ej6kiR6s0CKAsU76zuA32q4">Mobile and Wireless Network Security and Privacy</a></td><td>232 Pages</td></tr>
<tr><td>51.</td><td><a target="_blank" href="https://mega.nz/#!bewSkQRZ!LPhI_QegpdRxB_t1W4YuijNKYFFP94K2ThPBkEAw8Pc">Firewalls and Internet Security</a></td><td>456 Pages</td></tr>
<tr><td>52.</td><td><a target="_blank" href="https://mega.nz/#!af4STYpI!2aXpT4q-ss7HKdjTuljomvQ4pwVOfCQ928MdWrFmCL0">An Introduction to Computer Security - The NIST Handbook</a></td><td>290 Pages</td></tr>
<tr><td>53.</td><td><a target="_blank" href="https://mega.nz/#!iKw0FYgb!k47HRaTvm0IOkHZqrFDwjah6wtOg35bGXuM38vpEXck">Unauthorized Access - Physical Penetration Testing for IT Security Teams</a></td><td>309 Pages</td></tr>
<tr><td>54.</td><td><a target="_blank" href="https://mega.nz/#!ySg2wQzZ!XoUx3tZk7uX3WHY60YCLH0Qsvb_88QdpLl984LLnXgk">Testing Web Security</a></td><td>297 Pages</td></tr>
<tr><td>55.</td><td><a target="_blank" href="https://mega.nz/#!vWhkCAxQ!jenzhkq4xcn6M2fZ2RtSJYV_I52FRrDcnCG2HHVSSjE">Maximum Security - A Hacker's Guide to Protecting Your Internet Site and Network</a></td><td>670 Pages</td></tr>
<tr><td>56.</td><td><a target="_blank" href="https://mega.nz/#!aS5SFKjC!7kBBxcTv8NRqaRiimLdxoqXORmnq8d5C0baVXQf4AVE">Information Resource Guide - Computer, Internet and Network Systems Security</a></td><td>325 Pages</td></tr>
<tr><td>57.</td><td><a target="_blank" href="https://mega.nz/#!3WhABAJa!2DaRXVbMiWQsog2xnVMX0ElX6YmyVImE9rqK64HB5PQ">The Hacker's Underground Handbook</a></td><td>116 Pages</td></tr>
<tr><td>58.</td><td><a target="_blank" href="https://mega.nz/#!vKhUQC6a!I41OmN3rv9n5ifBzrHoZ02DM2XoI-K3xJrilFxBctzY">Guide to SCADA and Industrial Control Systems Security</a></td><td>164 Pages</td></tr>
<tr><td>59.</td><td><a target="_blank" href="https://mega.nz/#!De5QlKxR!FVNddZM0-iP-WEQfQoCYCAp9YRYQXJcr6z6n4FfeRV0">The International Handbook of Computer Security</a></td><td>274 Pages</td></tr>
<tr><td>60.</td><td><a target="_blank" href="https://mega.nz/#!LW5WjCQQ!AGo4nnpU0JESKz3OmWZaq1rU4g6KC0GozwKFlBLY8do">The Code Book - How to Make It, Break It, Hack It, Crack It</a></td><td>273 Pages</td></tr>
<tr><td>61.</td><td><a target="_blank" href="https://mega.nz/#!bShARQQY!Hnbv6rpt_R9Vbww3VGj2507gLHK_sdrz-9cv1eyj0Lk">Linux 101 Hacks</a></td><td>271 Pages</td></tr>
<tr><td>62.</td><td><a target="_blank" href="https://mega.nz/#!fa4gGa4Q!hI1QQb-6eEa46XNpU1Wy8Erz6OWJD9VvyWw0E71h8Xg">Introduction to Linux - A Hands on Guide</a></td><td>223 Pages</td></tr>
<tr><td>63.</td><td><a target="_blank" href="https://mega.nz/#!eXwCnYBb!5aeBTH-YmZeI_HlQSHil8CXKk38QFLJY3UTNWeA5UF4">Bluetooth Security</a></td><td>222 Pages</td></tr>
<tr><td>64.</td><td><a target="_blank" href="https://mega.nz/#!XS5gjCKK!eeKiqsxKtDPiGOcci26M1gB5AGBtu5P-iQCbuCKSfsU">IT Governance - A Manager's Guide to Data Security and ISO 27001/27002</a></td><td>385 Pages</td></tr>
<tr><td>65.</td><td><a target="_blank" href="https://mega.nz/#!HWxwkAQR!xdHC7XD5-yH839juAeihmmPjCQTY7tx7Up8Re5-x8jQ">Batch File Programming</a></td><td>155 Pages</td></tr>
<tr><td>66.</td><td><a target="_blank" href="https://mega.nz/#!WLxUgSxI!7q1yWyxagK0a07qBYsDR3u1vC8IHPqmLF82qxL9TKg8">Cracking the Coding Interview</a></td><td>310 Pages</td></tr>
<tr><td>67.</td><td><a target="_blank" href="https://mega.nz/#!HawCwQiZ!tzDutdj0jmhAA2CZkkQaQNw5EduFuCgAaHoe-F_ABy0">Dictionary of Networking</a></td><td>465 Pages</td></tr>
<tr><td>68.</td><td><a target="_blank" href="https://mega.nz/#!KLxwiYrR!zxFJRXbRIWytm79bVKgEYPwjEf6Re5Km-OgBDwe9KHk">Hacking Gmail</a></td><td>310 Pages</td></tr>
<tr><td>69.</td><td><a target="_blank" href="https://mega.nz/#!TXgQHCQL!aWtutgKTLfqFzQJcylqiofD0ax0est96Md2sxqEs90c">Linux Complete Command Reference</a></td><td>1528 Pages</td></tr>
<tr><td>70.</td><td><a target="_blank" href="https://mega.nz/#!uCoU1CJJ!C1h-JhJu-4IQK36hF3ZbU2cJpPZol2nSP-vt_eeSr48">Practical Hacking Techniques and Countermeasures</a></td><td>752 Pages</td></tr>
<tr><td>71.</td><td><a target="_blank" href="https://mega.nz/#!6Kh0kYgS!IoR3Q7iX680RdEFmIjllNFoLlBFxuJ7SR-L26W-yYg0">The Art of Intrusion by Kevin Mitnick</a></td><td>291 Pages</td></tr>
<tr><td>72.</td><td><a target="_blank" href="https://mega.nz/#!qLhAWAhY!ShdnfmCy3cOCe3Mxzmo2fy3cbwul2XffCbc2DWHm_SY">Hack Notes - Windows Security Portable Reference</a></td><td>289 Pages</td></tr>
<tr><td>73.</td><td><a target="_blank" href="https://mega.nz/#!ee5QWY7B!Ut6N4uuAfTNDc7EEJnvqjGp9CBn-cDafT4dI48UzM5M">Hacing - The Next Generation</a></td><td>298 Pages</td></tr>
<tr><td>74.</td><td><a target="_blank" href="https://mega.nz/#!KL4AUIzQ!iFdVoIfY91zn4tlVsiDVgjC2XoLnge6Zy0_FaRpZSkw">Hacking the Cable Modem</a></td><td>330 Pages</td></tr>
<tr><td>75.</td><td><a target="_blank" href="https://mega.nz/#!OfgSiCqS!sg_WqSUwKcpYjWrmeERZHkxh8qK5cUUV0KBXEWo8ux4">Hackers Beware - Defending Your Network From The Wiley Hacker</a></td><td>817 Pages</td></tr>
<tr><td>76.</td><td><a target="_blank" href="https://mega.nz/#!jX5AAaKJ!R7baBKxN7Y7WgNMd1AJu8Qe_VCsW6xuk5sTMhoZCmRU">Hack Proofing Your Network</a></td><td>826 Pages</td></tr>
<tr><td>77.</td><td><a target="_blank" href="https://mega.nz/#!bPxGyQ5B!J4ui9cgeR-LU1GWYVyPjPOcSpdvKjmhY-NwI1qW-kb8">Hack Attacks Revealed</a></td><td>837 Pages</td></tr>
<tr><td>78.</td><td><a target="_blank" href="https://mega.nz/#!OW5QyKIK!Dc20fhN8vX6Lhla2hkjdaGAPTf4Z6SIZsU9VgqoKLXo">Dissecting the Hack - The F0rb1dd3n Network</a></td><td>441 Pages</td></tr>
<tr><td>79.</td><td><a target="_blank" href="https://mega.nz/#!HWhyRSwC!Pzp2QuDtNQHMux7uqOEWf3Y6mCZVpvwfVuxFIlP2Gks">TCP/IP Guide</a></td><td>1671 Pages</td></tr>
<tr><td>80.</td><td><a target="_blank" href="https://mega.nz/#!vHhCnYhA!TsY57So4OXdyniAQdnmtajPBxZAXvsdXaPI3wl9zFYg">Offensive Security - Wireless Attacks - WiFu</a></td><td>385 Pages</td></tr>
<tr><td>81.</td><td><a target="_blank" href="https://mega.nz/#!2exEiIQa!z15nwhT4MsCvJAY0GxZBgQ2sglEgF0faAWDNid7pMxo">Google Hacking - For Penetration Testers</a></td><td>529 Pages</td></tr>
<tr><td>82.</td><td><a target="_blank" href="https://mega.nz/#!nKpmhQZL!7B6swnmDKJnKxkVCCF_y_bHGGgWmFoJNpjWQPLlsrgs">Computer Forensics Investigating Network Intrusions and Cyber Crime</a></td><td>394 Pages</td></tr>
<tr><td>83.</td><td><a target="_blank" href="https://mega.nz/#!Wf4kkICJ!BWMBUXPw77XN5ikocb61z21s54aeWmY3w73Q4kX5KZk">Hakin9 Bible</a></td><td>207 Pages</td></tr>
<tr><td>84.</td><td><a target="_blank" href="https://mega.nz/#!TThyEAha!JO331oy2Dk-IkACgAQOaGGE26LX421QDTcgahMFlq1o">Network Forensics - Tracking Hackers Through Cyberspace</a></td><td>574 Pages</td></tr>
<tr><td>85.</td><td><a target="_blank" href="https://mega.nz/#!eD5mRIDB!82Vp2yxE0J2MSQ6iPDViLagrSti08ON6LT45HcSRQdw">Computer Forensics - Investigating Data and Image Files</a></td><td>227 Pages</td></tr>
<tr><td>86.</td><td><a target="_blank" href="https://mega.nz/#!zHhGBKDL!sD-gNbVyS_kh30hY4RP85p2e5fnmcA8gGkpc1TvNdx8">Penetration Testing and Network Defense</a></td><td>625 Pages</td></tr>
<tr><td>87.</td><td><a target="_blank" href="https://mega.nz/#!iHwwRSCZ!5-xIqpaX3ZKlcWKDcKUvAiBlnhS0PJIcdE8JpQBy7cQ">Hacking Exposed - Malware and Rootkits</a></td><td>401 Pages</td></tr>
<tr><td>88.</td><td><a target="_blank" href="https://mega.nz/#!3fhiSShZ!YsRYTHeedcLohNpj8HmrIB86VZIRYd_MQIoOaUlhelk">Malware Analyst's Cookbook</a></td><td>746 Pages</td></tr>
<tr><td>89.</td><td><a target="_blank" href="https://mega.nz/#!vWxATKgD!1J8CWb2F8QQ7tM2IoehHdj4d0zqtZC35BW4UhKntAIY">Mobile Malware - Attacks and Defense</a></td><td>386 Pages</td></tr>
<tr><td>90.</td><td><a target="_blank" href="https://mega.nz/#!fW4QBKYA!VP02L9eUYydimUUecNgmfAGmy27lkKYCu3vd-2XBe4Y">Java 2 Network Security</a></td><td>702 Pages</td></tr>
<tr><td>91.</td><td><a target="_blank" href="https://mega.nz/#!jXoyDQST!DIDP_AtW5044Ec7chE70SAcwDgjim1nP_-iCPhsVRr4">A Bug Hunter's Diary</a></td><td>212 Pages</td></tr>
<tr><td>92.</td><td><a target="_blank" href="https://mega.nz/#!qa5kTYrK!k54v8jyljDLp5UFit1a0wYdovy4l-t5hFXhdRGRA-Z4">Viruses Revealed - Undestand and Counter Malicious Software</a></td><td>721 Pages</td></tr>
<tr><td>93.</td><td><a target="_blank" href="https://mega.nz/#!nPo2yI6R!rFBGgNWmQRrMbwuBbL4QlNUUtWJmaZ5hLzG7QrNvVAk">Figital Forensics With Open Source Tools</a></td><td>289 Pages</td></tr>
<tr><td>94.</td><td><a target="_blank" href="https://mega.nz/#!nX5gHCjS!vdRejQKWoOBB5ADpsciwODys4EszjWFNjTaltJcyQ7w">SSH, The Secure Shell - The Definitive Guide</a></td><td>438 Pages</td></tr>
<tr><td>95.</td><td><a target="_blank" href="https://mega.nz/#!uO5EDA5B!KuLXrn9rqzRxHVqygUSIkThb1HS0iHCDRRiuqNHLa9o">Pro PHP Security</a></td><td>369 Pages</td></tr>
<tr><td>96.</td><td><a target="_blank" href="https://mega.nz/#!fC5CiaLL!f9u2h1diOMm2b1eD00DdEF8EyVAdrIgzz4V_JHrqtTo">Zero Day Exploit - Countdown to Darkness</a></td><td>363 Pages</td></tr>
<tr><td>97.</td><td><a target="_blank" href="https://mega.nz/#!XDo0yQza!DxM3BhfZsZvFqHRu9fY9011wFQD1Zc5S3kLrxnXP59Q">Metasploit Penetration Testing Cookbook</a></td><td>269 Pages</td></tr>
<tr><td>98.</td><td><a target="_blank" href="https://mega.nz/#!nLpw2abD!Tla1GsHPg6NzxdExbd03jK5--hr62-R_xG6aHaI4374">24 Deadly Sins of Software Securtiy</a></td><td>433 Pages</td></tr>
<tr><td>99.</td><td><a target="_blank" href="https://mega.nz/#!DPhQ3ICB!hUk6UqVzfcfyPL3ftYx7HR6d9HNo7p8IdUQjNMlOCTQ">Botnets - The Killer Web App</a></td><td>482 Pages</td></tr>
<tr><td>100.</td><td><a target="_blank" href="https://mega.nz/#!DKoWUI5B!WXfTCl5-quuooEq1xf-MOtm3iMaDLOt8v9X3hTm4rA8">Hacker Highschool - Hack School for Beginners (ZIP)</a></td><td>12 Books</td></tr>
</table>

For any broken link, please drop a mail at yeahhub@gmail.com
