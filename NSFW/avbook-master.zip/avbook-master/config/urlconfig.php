<?php

return ['avmoohost'=>'avmoo.asia',
    'javbushost'=>'www.javbus.life',
    'javlibhost'=>'www.c32r.com',
    'btsourl' => 'https://btsow.pw/search/'
];
