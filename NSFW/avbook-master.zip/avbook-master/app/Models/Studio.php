<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Studio extends Model
{
    protected $table = 'avbook_avmoo_studio';
    public $timestamps = false;
}
