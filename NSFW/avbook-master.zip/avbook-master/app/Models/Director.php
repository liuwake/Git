<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Director extends Model
{
    protected $table = 'avbook_avmoo_director';
    public $timestamps = false;
}
