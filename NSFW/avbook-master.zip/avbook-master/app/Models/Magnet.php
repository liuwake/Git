<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Magnet extends Model
{
    protected $table = 'avbook_javbus_magnet';
    public $timestamps = false;
}
