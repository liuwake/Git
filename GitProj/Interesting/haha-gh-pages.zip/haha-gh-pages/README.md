haha
====

蛤蛤体生成器

http://dkwingsmt.github.io/haha



License
====
Public domain. 
