while ($true) {
    Write-Host "e" -NoNewLine;
}
