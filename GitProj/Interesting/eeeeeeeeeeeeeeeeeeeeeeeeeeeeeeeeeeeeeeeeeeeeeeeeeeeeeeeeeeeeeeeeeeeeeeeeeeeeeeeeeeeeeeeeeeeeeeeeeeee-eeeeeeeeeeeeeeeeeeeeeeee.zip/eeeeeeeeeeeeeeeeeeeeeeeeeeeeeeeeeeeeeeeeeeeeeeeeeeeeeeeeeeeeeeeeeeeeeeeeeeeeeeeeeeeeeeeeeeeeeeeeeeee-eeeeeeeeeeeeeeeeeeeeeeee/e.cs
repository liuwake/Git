using Eeeeeee = System.Console;
using eeee = System.Boolean;

namespace e
{
    class E
    {
        const eeee e = true;
        
        static void Main(string[] eeee)
        {
            while (e)
            {
                Eeeeeee.Write('e');
            }
        }
    }
}
