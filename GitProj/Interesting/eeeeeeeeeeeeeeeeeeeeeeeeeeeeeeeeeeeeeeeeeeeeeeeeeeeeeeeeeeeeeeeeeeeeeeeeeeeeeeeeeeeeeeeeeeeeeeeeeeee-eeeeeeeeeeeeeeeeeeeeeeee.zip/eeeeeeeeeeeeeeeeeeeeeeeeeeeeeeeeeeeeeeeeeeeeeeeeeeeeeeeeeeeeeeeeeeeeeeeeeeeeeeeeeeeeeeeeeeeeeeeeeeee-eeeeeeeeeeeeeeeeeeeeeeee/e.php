<?php
while (true) echo "e";
