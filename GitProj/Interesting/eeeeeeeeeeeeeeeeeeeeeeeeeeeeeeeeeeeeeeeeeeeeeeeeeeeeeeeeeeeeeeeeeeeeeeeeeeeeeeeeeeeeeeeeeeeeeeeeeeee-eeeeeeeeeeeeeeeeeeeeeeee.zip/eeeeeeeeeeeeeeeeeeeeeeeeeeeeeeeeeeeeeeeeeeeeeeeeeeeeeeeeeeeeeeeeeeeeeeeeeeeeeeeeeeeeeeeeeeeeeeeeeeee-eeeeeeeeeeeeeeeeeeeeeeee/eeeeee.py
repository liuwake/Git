"""EEe ee eeeee eee"""
from itertools import repeat as eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
eeeeeeeeeeeeeeeeeeeeeeee = any
eeeeeeeee = map
eeeeeeeeeeeeeeee = print
e = 'e'
eeeeeeeeeeeeeeeeeeeeeeee(eeeeeeeee(eeeeeeeeeeeeeeee, eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee(e)))

# eeee
