object e extends App {
  Stream.continually("e").foreach(print)
}
