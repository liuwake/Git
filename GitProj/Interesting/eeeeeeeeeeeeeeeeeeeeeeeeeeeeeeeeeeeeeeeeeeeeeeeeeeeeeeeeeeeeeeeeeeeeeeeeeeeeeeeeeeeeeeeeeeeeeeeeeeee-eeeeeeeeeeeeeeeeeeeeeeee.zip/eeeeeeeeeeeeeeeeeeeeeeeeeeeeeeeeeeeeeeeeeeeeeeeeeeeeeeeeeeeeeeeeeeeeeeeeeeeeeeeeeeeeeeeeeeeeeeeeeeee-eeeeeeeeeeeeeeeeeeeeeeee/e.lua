while e==e do
    print('e')
end
