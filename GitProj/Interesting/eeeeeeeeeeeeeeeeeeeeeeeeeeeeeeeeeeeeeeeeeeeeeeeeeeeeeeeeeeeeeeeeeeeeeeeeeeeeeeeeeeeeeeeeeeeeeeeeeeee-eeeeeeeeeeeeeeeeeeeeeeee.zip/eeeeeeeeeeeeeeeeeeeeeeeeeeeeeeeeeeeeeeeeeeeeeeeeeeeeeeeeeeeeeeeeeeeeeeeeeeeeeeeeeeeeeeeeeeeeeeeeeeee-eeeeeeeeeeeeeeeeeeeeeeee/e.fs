: E 1 0 DO ." e" 0 +LOOP ;
E ;
