[<EntryPoint>]
let e ee = 
  while 'e' = 'e' do
    printf "e"
  int 'e'
