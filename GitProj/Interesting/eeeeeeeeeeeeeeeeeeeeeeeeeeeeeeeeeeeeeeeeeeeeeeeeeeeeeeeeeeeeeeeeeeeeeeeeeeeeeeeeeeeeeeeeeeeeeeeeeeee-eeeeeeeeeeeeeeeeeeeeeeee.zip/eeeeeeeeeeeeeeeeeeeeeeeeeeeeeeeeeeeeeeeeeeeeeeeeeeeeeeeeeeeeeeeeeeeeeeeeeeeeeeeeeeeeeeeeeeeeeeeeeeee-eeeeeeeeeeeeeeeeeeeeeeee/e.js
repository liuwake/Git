while ('e') console.log('e');
