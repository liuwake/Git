#include <unistd.h>
#define e "e"
#define ee e e
#define eee ee ee
#define eeee eee eee
#define eeeee eeee eeee
#define eeeeee eeeee eeeee
#define eeeeeee eeeeee eeeeee
#define eeeeeeee eeeeeee eeeeeee
#define eeeeeeeee eeeeeeee eeeeeeee
#define eeeeeeeeee eeeeeeeee eeeeeeeee
#define eeeeeeeeeee eeeeeeeeee eeeeeeeeee
#define eeeeeeeeeeee eeeeeeeeeee eeeeeeeeeee
#define eeeeeeeeeeeee eeeeeeeeeeee eeeeeeeeeeee
#define eeeeeeeeeeeeee eeeeeeeeeeeee eeeeeeeeeeeee
#define eeeeeeeeeeeeeee eeeeeeeeeeeeee eeeeeeeeeeeeee
#define e_e_e(e, ee, eee) write(e, ee, eee)
#define e_e() int main()
#define e_(e) while(e)

e_e() { e_(e) e_e_e(1, eeeeeeeeeeeeeee, 0x4000); }
