main = putStr $ cycle "e"

