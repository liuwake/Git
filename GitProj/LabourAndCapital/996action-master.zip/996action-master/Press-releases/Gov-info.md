# 信息公开：996icu爆发一个月，我很关心劳动监察部门

2019年4月29日，反抗996工作制的行动板块996行动（996action）的第一次行动——向八个加班热门城市的社会保障和人力资源局寄送进行公开，正式开展。这是996icu发展一个月后的第一次实名线下行动。

![图片](https://github.com/CPdogson/996action/blob/master/Gov-info/ppic1.jpg)

这项运动最开始的设计是在清明节之后，996的社区里一名叫狗崽的劳动者发起的，他将他的计划写在了他自己的板块，并详细分析了为什么要进行信息公开：做信息公开除了关心一下劳动监察部门在996icu爆发的一个月中做了些什么以外，也想关心一下他们的年度计划和案件处理数量。“因为超额加班这么严重，应该有很多相关的案件吧。”狗崽表示，他很担心劳动监察部门因为996icu的事情加班处理案件，希望他们不要因为996icu爆发而进行996的劳作。

![图片](https://github.com/CPdogson/996action/blob/master/Gov-info/ppic2.jpg)

出于一片好心，许多劳动者朋友响应号召寄出了信息公开，对北京、上海、广州、深圳、杭州、成都、南京、苏州这八个城市进行了关心，要求这几个市的社会保障和人力资源局公开两年内的工作计划、案件报表以及这一个月做了些什么。狗崽对《信息公开条例》、《劳动保障监察条例》、《关于实施<劳动保障监察条例>若干规定》做了一些分析，他认为社会保障和人力资源局手上应该有这些资料。

![图片](https://github.com/CPdogson/996action/blob/master/Gov-info/ppic3.jpg)

2019年4月29日下午，996行动板块收到了第一份邮寄回执，有网友向5个省市寄出了自己的关怀，他表示：“自己已经没有在996了，但是我被折磨过，只是希望以后所有同行，所有其他行业的劳动者，都能真正的被科技解放人力，而不是变得更累。”

据狗崽说，这次行动参与会议并表示会寄出信息公开的邮件组内有二十多人，如今还在努力的联系这些人收集他们寄出的线索，也希望今后能有更多的人可以通过信息公开来关心劳动保障监察部门的努力。

![成都](https://github.com/CPdogson/996action/blob/master/Gov-info/g7-cd.jpg)
![苏州](https://github.com/CPdogson/996action/blob/master/Gov-info/g7-jssz.jpg)
![南京](https://github.com/CPdogson/996action/blob/master/Gov-info/g7-nj.jpg)
![杭州](https://github.com/CPdogson/996action/blob/master/Gov-info/g7-hz.jpg)
![深圳](https://github.com/CPdogson/996action/blob/master/Gov-info/g7-sz.jpg)
     
