> 本页面为[关于《劳动保障监察条例》第二十五条、第三十条规定的修改建议以及对十四条规定的完善建议](https://github.com/CPdogson/996action/blob/master/change-law.md)的签名公开页面，如被冒签，可以自行PR或者邮件至CPdogson@protonmail.com

> 如不擅长PR，可以点击[第三方渠道](https://www.996action.com/index.php/293988?lang=zh-Hans)

实名签名

姓名|工作地点（省）|职业|身份证后四位/手机号后四位
---|-----|-----|----
例子|北京|程序员|2345

匿名签名

昵称|职业
---|----
李子|码农
